import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"

const menuItems = [
  {
    id: 1,
    name: "Brigadeiro Tradicional",
    description: "Brigadeiro tradicional com chocolate belga e granulado especial",
    price: "R$ 3,50",
    category: "brigadeiros",
    image: "/brigadeiro.png",
  },
  {
    id: 2,
    name: "Brigadeiro Branco",
    description: "Brigadeiro de chocolate branco com granulado",
    price: "R$ 3,50",
    category: "brigadeiros",
    image: "/brigadeiros.JPG",
  },
  {
    id: 3,
    name: "Brigadeiro de Pistache",
    description: "Brigadeiro gourmet com pistache e cobertura especial",
    price: "R$ 4,50",
    category: "brigadeiros",
    image: "/brigadeiros.JPG",
  },
  {
    id: 4,
    name: "Brownie",
    description: "Brownie macio com gotas de chocolate meio amargo",
    price: "R$ 8,90",
    category: "bolos",
    image: "/browniemarmita.JPG",
  },
  {
    id: 5,
    name: "Bolo de Chocolate",
    description: "Bolo de chocolate com cobertura de ganache",
    price: "R$ 65,00",
    category: "bolos",
    image: "/bolo de pote.png",
  },
  {
    id: 6,
    name: "Bolo de Pote",
    description: "Bolo de pote com recheio de brigadeiro e morangos",
    price: "R$ 12,90",
    category: "bolos",
    image: "/bolo de pote.png",
  },
  {
    id: 7,
    name: "Cookie de Chocolate",
    description: "Cookie crocante com gotas de chocolate",
    price: "R$ 6,50",
    category: "cookies",
    image: "/cookie.png",
  },
  {
    id: 8,
    name: "Cookie de Baunilha",
    description: "Cookie de baunilha com gotas de chocolate branco",
    price: "R$ 6,50",
    category: "cookies",
    image: "/cookie.JPG",
  },
  {
    id: 9,
    name: "Combo Festa (50 unidades)",
    description: "Mix de brigadeiros tradicionais e gourmet",
    price: "R$ 89,90",
    category: "combos",
    image: "/combo1.JPG",
  },
  {
    id: 10,
    name: "Caixa Presente",
    description: "Caixa com 12 brigadeiros sortidos",
    price: "R$ 45,00",
    category: "combos",
    image: "/4ovos.png",
  },
  {
    id: 11,
    name: "Combo Degustação",
    description: "Mix com 6 tipos diferentes de doces",
    price: "R$ 35,00",
    category: "combos",
    image: "/3ovospascoa.png",
  },
  {
    id: 12,
    name: "Festa Completa",
    description: "Kit completo com doces variados para 20 pessoas",
    price: "R$ 199,90",
    category: "combos",
    image: "/coelhopascoa.png",
  },
]

export default function MenuGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {menuItems.map((item) => (
        <Card key={item.id} className="overflow-hidden group">
          <div className="relative h-48 overflow-hidden">
            <Image
              src={item.image || "/placeholder.svg"}
              alt={item.name}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </div>
          <CardContent className="p-4">
            <div className="mb-2">
              <h3 className="font-bold">{item.name}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
            </div>
            <div className="flex justify-between items-center mt-4">
              <span className="font-medium text-primary">{item.price}</span>
              <Button size="sm" variant="outline">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Adicionar
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
