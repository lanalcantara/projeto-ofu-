import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="relative">
      <div className="absolute inset-0 z-0">
        <Image src="/IMG_0098.JPG" alt="Doces artesanais" fill className="object-cover brightness-[0.7]" priority />
      </div>

      <div className="container relative z-10 flex min-h-[600px] flex-col items-center justify-center text-center py-24">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
          Doces Artesanais com Sabor de Felicidade
        </h1>
        <p className="mt-6 max-w-md text-lg text-white/90">
          Descubra o sabor único dos nossos doces artesanais, feitos com ingredientes selecionados e muito carinho.
        </p>
        <div className="mt-10 flex flex-wrap gap-4 justify-center">
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Ver Cardápio
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-background/20 text-white hover:bg-background/30 backdrop-blur-sm"
          >
            Fazer Pedido
          </Button>
        </div>
      </div>
    </section>
  )
}
