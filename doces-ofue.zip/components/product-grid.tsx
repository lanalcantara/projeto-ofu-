import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"

const products = [
  {
    id: 1,
    name: "Brigadeiro Tradicional",
    price: "R$ 3,50",
    image: "/brigadeiro.png",
  },
  {
    id: 2,
    name: "Brigadeiro Branco",
    price: "R$ 3,50",
    image: "/brigadeiros.JPG",
  },
  {
    id: 3,
    name: "Brigadeiro de Pistache",
    price: "R$ 4,50",
    image: "/brigadeiros.JPG",
  },
  {
    id: 4,
    name: "Brownie",
    price: "R$ 8,90",
    image: "/browniemarmita.JPG",
  },
  {
    id: 5,
    name: "Cookie de Chocolate",
    price: "R$ 6,50",
    image: "/cookie.png",
  },
  {
    id: 6,
    name: "Bolo de Pote",
    price: "R$ 12,90",
    image: "/bolo de pote.png",
  },
  {
    id: 7,
    name: "Combo Festa",
    price: "R$ 89,90",
    image: "/combo1.JPG",
  },
  {
    id: 8,
    name: "Caixa Presente",
    price: "R$ 45,00",
    image: "/4ovos.png",
  },
]

export default function ProductGrid() {
  return (
    <section className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h2 className="text-3xl font-bold text-primary">Nossos Produtos</h2>
        <p className="mt-4 text-muted-foreground max-w-2xl">
          Explore nossa variedade de doces artesanais, feitos com ingredientes selecionados e muito amor.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <Card key={product.id} className="overflow-hidden group">
            <div className="relative h-48 overflow-hidden">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold">{product.name}</h3>
                <span className="font-medium text-primary">{product.price}</span>
              </div>
              <Button size="sm" variant="outline" className="w-full mt-2">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Adicionar
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
