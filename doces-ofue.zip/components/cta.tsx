import { Button } from "@/components/ui/button"

export default function CTA() {
  return (
    <section className="container py-16">
      <div className="rounded-xl bg-primary/10 p-8 md:p-12 text-center">
        <h2 className="text-3xl font-bold font-display text-primary mb-4">Pronto para experimentar nossos doces?</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
          Faça seu pedido agora mesmo e receba em casa ou retire na loja. Também aceitamos encomendas para festas e
          eventos especiais.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Fazer Pedido
          </Button>
          <Button size="lg" variant="outline">
            Ver Cardápio Completo
          </Button>
        </div>
      </div>
    </section>
  )
}
