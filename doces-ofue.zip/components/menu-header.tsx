import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MenuHeader() {
  return (
    <div className="mb-12">
      <h1 className="text-4xl font-bold text-center mb-6 font-display text-primary">Nosso Cardápio</h1>
      <p className="text-center text-muted-foreground max-w-2xl mx-auto mb-8">
        Conheça nossa variedade de doces artesanais, feitos com ingredientes selecionados e muito amor. Todos os
        produtos podem ser encomendados para festas e eventos.
      </p>

      <Tabs defaultValue="todos" className="w-full max-w-2xl mx-auto">
        <TabsList className="grid grid-cols-5 w-full">
          <TabsTrigger value="todos">Todos</TabsTrigger>
          <TabsTrigger value="brigadeiros">Brigadeiros</TabsTrigger>
          <TabsTrigger value="bolos">Bolos</TabsTrigger>
          <TabsTrigger value="cookies">Cookies</TabsTrigger>
          <TabsTrigger value="combos">Combos</TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  )
}
