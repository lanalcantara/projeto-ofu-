"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Menu, X } from "lucide-react"
import { ModeToggle } from "./mode-toggle"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
          <Link href="/" className="text-2xl font-bold text-primary">
            Doces Ofuê
          </Link>
        </div>

        <nav
          className={`${isMenuOpen ? "absolute inset-x-0 top-16 border-b bg-background p-4 md:static md:border-0 md:bg-transparent md:p-0" : "hidden md:flex"} flex-col gap-4 md:flex-row md:items-center`}
        >
          <Link href="/" className="text-foreground hover:text-primary transition-colors">
            Início
          </Link>
          <Link href="/cardapio" className="text-foreground hover:text-primary transition-colors">
            Cardápio
          </Link>
          <Link href="/sobre" className="text-foreground hover:text-primary transition-colors">
            Sobre Nós
          </Link>
          <Link href="/contato" className="text-foreground hover:text-primary transition-colors">
            Contato
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <ModeToggle />
          <Button size="icon" variant="outline">
            <ShoppingCart className="h-5 w-5" />
            <span className="sr-only">Carrinho</span>
          </Button>
          <Button className="hidden md:inline-flex">Fazer Pedido</Button>
        </div>
      </div>
    </header>
  )
}
