import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "Maria Silva",
    text: "Os brigadeiros são simplesmente divinos! Sempre peço para festas e eventos, e todos adoram.",
    rating: 5,
    image: "/brigadeiro.png",
  },
  {
    id: 2,
    name: "João Santos",
    text: "O brownie com Nutella é o melhor que já provei. Textura perfeita e sabor incrível!",
    rating: 5,
    image: "/browniemarmita.JPG",
  },
  {
    id: 3,
    name: "Ana Oliveira",
    text: "Encomendei para o aniversário da minha filha e foi um sucesso. Doces deliciosos e apresentação impecável.",
    rating: 5,
    image: "/cookie.png",
  },
]

export default function Testimonials() {
  return (
    <section className="bg-muted/30 py-16">
      <div className="container">
        <div className="flex flex-col items-center text-center mb-12">
          <h2 className="text-3xl font-bold text-primary">O que nossos clientes dizem</h2>
          <p className="mt-4 text-muted-foreground max-w-2xl">
            A satisfação dos nossos clientes é nossa maior recompensa. Confira alguns depoimentos.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="bg-background">
              <CardContent className="p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="mb-6 text-muted-foreground">"{testimonial.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="relative h-12 w-12 overflow-hidden rounded-full">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">Cliente</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
