import { MapPin, Phone, Mail, Clock } from "lucide-react"

export default function ContactInfo() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Informações de Contato</h2>
        <p className="text-muted-foreground">
          Entre em contato conosco para fazer encomendas, tirar dúvidas ou solicitar orçamentos para eventos.
        </p>
      </div>

      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <MapPin className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-bold">Endereço</h3>
            <p className="text-muted-foreground">Rua dos Doces, 123 - Centro</p>
            <p className="text-muted-foreground">São Paulo, SP - CEP 01234-567</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Phone className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-bold">Telefone</h3>
            <p className="text-muted-foreground">(11) 99999-9999</p>
            <p className="text-muted-foreground">(11) 3333-3333</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Mail className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-bold">Email</h3>
            <p className="text-muted-foreground">contato@docesofue.com.br</p>
            <p className="text-muted-foreground">vendas@docesofue.com.br</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Clock className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-bold">Horário de Funcionamento</h3>
            <p className="text-muted-foreground">Segunda a Sexta: 9h às 18h</p>
            <p className="text-muted-foreground">Sábado: 9h às 13h</p>
          </div>
        </div>
      </div>

      <div className="rounded-lg overflow-hidden border h-64 mt-8">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1975874301953!2d-46.65429492376397!3d-23.56388066183402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0aa315%3A0xd59f9431f2c9776a!2sAv.%20Paulista%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1682531248751!5m2!1spt-BR!2sbr"
          width="100%"
          height="100%"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </div>
  )
}
