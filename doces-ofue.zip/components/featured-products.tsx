import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const featuredProducts = [
  {
    id: 1,
    name: "Brigadeiro Gourmet",
    description: "Brigadeiro tradicional com chocolate belga e granulado especial",
    image: "/brigadeiro.png",
    badge: "Mais Vendido",
  },
  {
    id: 2,
    name: "Brownie com Nutella",
    description: "Brownie macio com cobertura generosa de Nutella",
    image: "/browniemarmita.JPG",
    badge: "Novo",
  },
  {
    id: 3,
    name: "Cookies de Chocolate",
    description: "Cookies crocantes com gotas de chocolate meio amargo",
    image: "/cookie.png",
    badge: "Favorito",
  },
]

export default function FeaturedProducts() {
  return (
    <section className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h2 className="text-3xl font-bold text-primary">Destaques da Semana</h2>
        <p className="mt-4 text-muted-foreground max-w-2xl">
          Conheça nossos produtos mais populares, feitos com ingredientes selecionados e muito carinho.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {featuredProducts.map((product) => (
          <Card key={product.id} className="overflow-hidden group">
            <div className="relative h-64 overflow-hidden">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
              {product.badge && <Badge className="absolute top-4 right-4 bg-primary">{product.badge}</Badge>}
            </div>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">{product.name}</h3>
              <p className="text-muted-foreground">{product.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
