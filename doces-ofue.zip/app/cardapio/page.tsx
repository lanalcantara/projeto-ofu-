import type { Metadata } from "next"
import MenuHeader from "@/components/menu-header"
import MenuGrid from "@/components/menu-grid"

export const metadata: Metadata = {
  title: "Cardápio - Doces Ofuê",
  description: "Conheça nosso cardápio completo de doces artesanais",
}

export default function CardapioPage() {
  return (
    <div className="container mx-auto py-12">
      <MenuHeader />
      <MenuGrid />
    </div>
  )
}
