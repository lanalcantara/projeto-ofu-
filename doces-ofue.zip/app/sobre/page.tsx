import type { Metadata } from "next"
import Image from "next/image"

export const metadata: Metadata = {
  title: "Sobre Nós - Doces Ofuê",
  description: "Conheça a história da Doces Ofuê e nossa paixão por doces artesanais",
}

export default function SobrePage() {
  return (
    <div className="container mx-auto py-12">
      <h1 className="text-4xl font-bold text-center mb-12 text-primary">Nossa História</h1>

      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-2xl font-bold mb-4">Como tudo começou</h2>
          <p className="text-muted-foreground mb-4">
            A Doces Ofuê nasceu da paixão por doces tradicionais brasileiros. Nossa jornada começou em uma pequena
            cozinha familiar, onde receitas passadas por gerações ganharam um toque especial e único.
          </p>
          <p className="text-muted-foreground">
            Hoje, mantemos o mesmo cuidado artesanal em cada doce que produzimos, selecionando os melhores ingredientes
            e preservando o sabor autêntico que conquistou nossos clientes.
          </p>
        </div>
        <div className="relative h-[400px] rounded-lg overflow-hidden">
          <Image src="/Ninho com Nutella.JPG" alt="História da Doces Ofuê" fill className="object-cover" />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="relative h-[400px] rounded-lg overflow-hidden md:order-2">
          <Image src="/brigadeiros.JPG" alt="Nossos valores" fill className="object-cover" />
        </div>
        <div className="md:order-1">
          <h2 className="text-2xl font-bold mb-4">Nossos valores</h2>
          <ul className="space-y-4">
            <li className="flex gap-2">
              <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">1</div>
              <div>
                <h3 className="font-bold">Qualidade</h3>
                <p className="text-muted-foreground">Selecionamos os melhores ingredientes para nossos doces.</p>
              </div>
            </li>
            <li className="flex gap-2">
              <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">2</div>
              <div>
                <h3 className="font-bold">Tradição</h3>
                <p className="text-muted-foreground">Preservamos receitas tradicionais com toques especiais.</p>
              </div>
            </li>
            <li className="flex gap-2">
              <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">3</div>
              <div>
                <h3 className="font-bold">Inovação</h3>
                <p className="text-muted-foreground">
                  Criamos novos sabores mantendo a essência dos doces brasileiros.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
