import Hero from "@/components/hero"
import ProductGrid from "@/components/product-grid"
import Testimonials from "@/components/testimonials"
import CTA from "@/components/cta"
import FeaturedProducts from "@/components/featured-products"

export default function Home() {
  return (
    <div className="flex flex-col gap-16 pb-16">
      <Hero />
      <FeaturedProducts />
      <ProductGrid />
      <Testimonials />
      <CTA />
    </div>
  )
}
